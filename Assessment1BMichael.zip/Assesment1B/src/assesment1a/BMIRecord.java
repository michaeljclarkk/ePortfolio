/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assesment1a;

/**
 *
 * @author 12188698
 */
public class BMIRecord {
//
    private String subId = "";
    private double height = 0;
    private double weight = 0;
    private double bValue = 0;
    private String cat = "";

    
    public BMIRecord(String subId, double height, double weight, double bValue, String cat) {
        this.subId = subId;
        this.height = height;
        this.bValue = bValue;
        this.cat = cat;
        this.weight = weight; 
    }

//These methods get the above parameters
    public String getSubjectId() {
        return subId;

    }

    public double getHeight() {
        return height;

    }

    public double getWeight() {
        return weight;

    }

    public double bValue() {
        return bValue;

    }

    public String cat() {
        return cat;
    }

   

}
