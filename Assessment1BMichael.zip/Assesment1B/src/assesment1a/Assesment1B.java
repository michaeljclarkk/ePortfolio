/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assesment1a;

/**
 *
 * @author 12188698
 */
public class Assesment1B {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        BMIAnalyser a = new BMIAnalyser();
        View v = new View(a);
        v.commandLoop();
    }

}
