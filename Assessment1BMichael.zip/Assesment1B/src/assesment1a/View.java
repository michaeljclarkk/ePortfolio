/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assesment1a;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 12188698
 */
public class View {

    private BMIAnalyser analyser;

    public View(BMIAnalyser a) {
        analyser = a;
    }

    private String help() {
        String help1 = " ";
        return "The following commands are recognised\n"
                + "\tDisplay this message                                   > 0\n"
                + "\tDisplay a specific subject record:                     > 1 subjectID\n"
                + "\tDisplay records for all subject records within a range > 2 bmi1 bmi2\n"
                + "\tDisplay all subject records                            > 3\n"
                + "\tDisplay statistics (minimum, maximum and average marks)> 4\n"
                + "\tExit the application                                   > 9";
    }

    public void commandLoop() {
        System.out.println(help());
        Scanner sc = new Scanner(System.in);
        int useri = sc.nextInt();
        String subId = " ";
        while (useri != 9) {
            switch (useri) {
                case 0:
                    System.out.print(this.help());
                    System.out.println(" ");
                    break;
                case 1:
               try {
                    subId = sc.next();
                    String up = subId.toUpperCase();
                    BMIRecord record = analyser.find(up);
                    Display(record);

                } catch (ArrayIndexOutOfBoundsException d) {
                    System.out.println("Error please enter Subject ID again Subject ID not found");
                    System.out.println(help());
                }
                break;
                case 2:

                    double bmi = sc.nextDouble();
                    double bmi2 = sc.nextDouble();
                    ArrayList<BMIRecord> listInRange = analyser.find(bmi, bmi2);
                    for (BMIRecord info : analyser.find(bmi, bmi2)) {

                        Display(info);

                    }
                    break;
                case 3:
                    for (BMIRecord BMIR : analyser.getData()) {
                        Display(BMIR);
                    }
                    break;
                case 4:
                    System.out.printf("Highest BMI is: %.1f \n", analyser.highestBMI());
                    System.out.printf("Lowest BMI is: %.1f \n", analyser.lowestBMI());
                    System.out.printf("Average BMI is: %.1f \n", analyser.averageBMI());
                    break;
                case 9:

                    System.exit(1);
            }
            useri = sc.nextInt();
        }
    }

    public void Display(BMIRecord i) {
        System.out.printf("< %s: Height: %.2f Weight %.2f BMI: %.2f Which is %s > %n", i.getsubjectId(), i.getHeight(), i.getWeight(), i.bValue(), i.cat());
    }
}
