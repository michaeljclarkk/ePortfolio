/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assesment1a;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author 12188698
 */
public class BMIAnalyser {

    private int nrecords;
    private BMIRecord[] data;


    public BMIAnalyser() {
        loadFromTables();
        sortById();
    }

    //Binary search algorithm.
    public BMIRecord find(String subId) {
        int low = 0;
        int high = data.length - 1;
        int middle = (low + high + 1) / 2;
        int location = -1;
        int result = subId.compareTo(data[middle].getsubjectId());  

        do {
            if (result == 0) {
                location = middle;
            } else if (result < 0) {
                high = middle - 1;

            } else {
                low = middle + 1;
            }
            middle = (low + high + 1) / 2;
            result = subId.compareTo(data[middle].getsubjectId());

        } while ((low <= high) && (location == -1));

        return new BMIRecord(subId, data[middle].getHeight(), data[middle].getWeight(), data[middle].bValue(), data[middle].cat());
    }

    public ArrayList<BMIRecord> find(double bmi, double bmi2) {
        ArrayList<BMIRecord> alr = new ArrayList<>();

        for (BMIRecord info : data) {
            if (info.bValue() > bmi && info.bValue() < bmi2) {
                alr.add(info);
              
            }

            
        }

        return alr;
    }
    
    
    //Methods to find the lowest, highest and average BMI. 
    public double lowestBMI() {
        double lowest = Double.MAX_VALUE;
        for (BMIRecord DV : data) {
            double bmi = DV.bValue();
            if (bmi < lowest) {
                lowest = bmi;
            }

        }
        return lowest;
    }

    public double highestBMI() {
        double highest = Double.MIN_VALUE;

        for (BMIRecord DV : data) {
            double bmi = DV.bValue();
            if (bmi > highest) {
                highest = bmi;
            }

        }
        return highest;
    }

    public double averageBMI() {
        double average = 0;
        for (BMIRecord DV : data) {
            double bmi = DV.bValue();
            average += bmi;
        }

        average = average / nrecords;
        return average;
    }

    public BMIRecord[] getData() {
        return data;

    }

    private int compareSubjectIds(BMIRecord s1, BMIRecord s2) {
        return s1.getsubjectId().compareTo(s2.getsubjectId());
    }

    private void sortById() {
        for (int i = 1; i < data.length; i++) {

        BMIRecord toInsert = data[i];

        int moveTo = i;

        while (moveTo > 0 && compareSubjectIds(data[moveTo - 1], toInsert) > 0) {
            data[moveTo] = data[moveTo - 1];
            moveTo--;
         
        }
         data[moveTo] = toInsert;
        }
        

    }

    private void loadFromTables() {
     String[] subjects = {"S01", "S02", "S03", "S04", "S05", "S06", "S07", "S08", "S09", "S10"
        };

        double[] height = {1.80, 1.90, 1.50, 1.69, 1.79, 1.92, 2.00, 1.89, 1.52, 1.49
        };
        double[] weight = {80, 100, 60, 78, 92, 56, 102, 80, 94, 79
        };


        nrecords = subjects.length;
        data = new BMIRecord[nrecords];
        for (int i = 0; i < nrecords; i++) {
            double v = weight[i] / (height[i] * height[i]);
            String c = classify(v);
            BMIRecord r = new BMIRecord(
                    subjects[i], height[i], weight[i], v, c);
            data[i] = r;

        }
    }


    private String classify(double bmi) {
        String class8 = " ";
        if (bmi > 0 && bmi <= 15) {
            class8 = " " + "severely underweight";
        } else if (bmi <= 15 && bmi < 16) {
            class8 = " " + "underweight";
        } else if (bmi <= 16 && bmi < 18.5) {
            class8 = " " + "slighty underweight";
        } else if (bmi <= 18.5 && bmi < 25) {
            class8 = " " + "healthy";
        } else if (bmi <= 25 && bmi < 30) {
            class8 = " " + "overweight";
        } else if (bmi <= 30 && bmi < 35) {
            class8 = " " + "mildly obese";
        } else if (bmi <= 35 && bmi < 40) {
            class8 = " " + "moderately obese";
        } else if (bmi <= 50) {
            class8 = " " + "severely obese";
        }
        return class8;

    }

}
